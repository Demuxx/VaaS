module BashesHelper
end
