module PuppetsHelper
end
