class Puppet < ActiveRecord::Base
end
