class Chef < ActiveRecord::Base
  has_many :chef_jsons
end
