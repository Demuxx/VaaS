class Bash < ActiveRecord::Base
end
