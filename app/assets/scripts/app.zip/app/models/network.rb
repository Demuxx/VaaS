class Network < ActiveRecord::Base
end
