class Log < ActiveRecord::Base
  belongs_to :machine
end
