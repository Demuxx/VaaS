class Box < ActiveRecord::Base
end
