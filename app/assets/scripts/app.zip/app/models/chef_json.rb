class ChefJson < ActiveRecord::Base
  belongs_to :chef
end
