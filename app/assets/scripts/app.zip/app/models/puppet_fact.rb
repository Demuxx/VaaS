class PuppetFact < ActiveRecord::Base
  belongs_to :puppet
end
