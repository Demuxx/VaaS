class PuppetOption < ActiveRecord::Base
  belongs_to :puppet
end
