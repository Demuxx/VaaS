class VisitorsController < ApplicationController

  def new
  end

end
